package tn.formalab.myproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toolbar;

import java.util.ArrayList;

public class Listmessage extends AppCompatActivity {


    ListView lv ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listmessage);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("LIST");

        lv = findViewById(R.id.listview);


        BDEntity bdEntity = new BDEntity(this);
        ArrayList<MyEntity> myEntities = bdEntity.getAllEntity();

        AdapterClass adapterClass = new AdapterClass(this,R.layout.model,myEntities);
        lv.setAdapter(adapterClass);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                MyEntity myEntity = (MyEntity) adapterView.getItemAtPosition(i);

                int id = myEntity.getId();

                Intent intent = new Intent(Listmessage.this,Updatemessage.class);
                intent.putExtra("id",id);
                startActivity(intent);
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if(id == android.R.id.home)
        {
            //this.finish();
            startActivity(new Intent(Listmessage.this,MainActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }
}

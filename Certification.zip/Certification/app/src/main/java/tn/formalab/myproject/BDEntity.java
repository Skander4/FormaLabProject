package tn.formalab.myproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Date;

public class BDEntity extends SQLiteOpenHelper {

    private static final String DB_Entity="FormalabDB";
    private static final int VERSION =1;
    private static final String TB_Entity="Entity";



    public BDEntity( Context context) {

        super(context, DB_Entity, null, VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String create =" CREATE TABLE "+TB_Entity+" ( id INTEGER PRIMARY KEY , message VARCHAR(30) , sender VARCHAR(30),time VARCHAR(30) );";
        sqLiteDatabase.execSQL(create);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String delete=" DROP TABLE IF EXISTS "+TB_Entity;
        sqLiteDatabase.execSQL(delete);
        onCreate(sqLiteDatabase);
    }

    public ArrayList<MyEntity> getAllEntity()
    {
        ArrayList<MyEntity> entities = new ArrayList<>();
        String query=" SELECT * FROM "+TB_Entity+" ;";
        SQLiteDatabase db =getReadableDatabase();

        Cursor cursor =db.rawQuery(query,null);
        if (cursor.moveToFirst())
        {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String message = cursor.getString(cursor.getColumnIndex("message"));
                String sender = cursor.getString(cursor.getColumnIndex("sender"));
                String date = cursor.getString(cursor.getColumnIndex("time"));
                MyEntity data = new MyEntity(id,message,sender,date);
                entities.add(data);

            }while (cursor.moveToNext());
        }
        return entities;
    }

    public  void AddEntity(MyEntity entity)
    {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("message",entity.getMessage());
        values.put("sender",entity.getSender());
        // a verfier
        values.put("time", entity.getTime());
        db.insert(TB_Entity,null,values);
    }

    public MyEntity UpdateEntity(MyEntity entity){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("message",entity.getMessage());
        values.put("sender",entity.getSender());
        // a verfier
        values.put("time", entity.getTime());

        db.update(TB_Entity,values,"id=?",new String[]{String.valueOf(entity.getId())});

        return entity;
    }

    public MyEntity getMessages(int id)
    {
        SQLiteDatabase db = getReadableDatabase();
        String query = " SELECT * FROM "+TB_Entity+" WHERE id = "+id;
        Cursor cursor = db.rawQuery(query,null);
        MyEntity myEntity = null;
        if (cursor.moveToFirst())
        {
            int idlocal = cursor.getInt(cursor.getColumnIndex("id"));
            String message = cursor.getString(cursor.getColumnIndex("message"));
            String sender = cursor.getString(cursor.getColumnIndex("sender"));
            String date = cursor.getString(cursor.getColumnIndex("time"));
            myEntity = new MyEntity(idlocal,message,sender,date);
        }
        return myEntity;
    }

    public void DeleteMessage(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TB_Entity,"id=?",new String[]{String.valueOf(id)});
    }
}

package tn.formalab.myproject;

import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

public class Updatemessage extends AppCompatActivity {


    EditText message,sender,time;
    Button submit;
    String format;
    int id;
    BDEntity bdEntity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updatemessage);

        message = findViewById(R.id.message);
        sender = findViewById(R.id.sender);
        time= findViewById(R.id.time);
        submit = findViewById(R.id.EditBtn);
        //  getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setTitle("SEND");

        Intent intent = getIntent();
        id = intent.getIntExtra("id",0);

        bdEntity = new BDEntity(this);

        MyEntity myEntity = bdEntity.getMessages(id);

        message.setText(myEntity.getMessage());
        sender.setText(myEntity.getSender());
        time.setText(myEntity.getTime());

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                AlertDialog alertDialog =new AlertDialog.Builder(Updatemessage.this)
                        //set message, title, and icon
                        .setTitle("Confirmation")
                        .setMessage("Voulez-vous modifier ce message?")
                        //.setIcon(R.drawable.formalab)

                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int whichButton) {
                                String msg = message.getText().toString();
                                String snd = sender.getText().toString();
                                String tm = time.getText().toString();


                                MyEntity myEntity1 = new MyEntity(id,msg,snd,tm);
                                bdEntity.UpdateEntity(myEntity1);


                                Intent i = new Intent(Updatemessage.this,Listmessage.class);
                                startActivity(i);
                               // dialog.dismiss();
                            }

                        })



                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.dismiss();

                            }
                        })
                        .show();


            }
        });

        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TimePickerDialog timePickerDialog = new TimePickerDialog(Updatemessage.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                        showTime(hourOfDay,minutes);
                        time.setText(hourOfDay + ":" + minutes + " "+format);
                    }
                }, 0, 0, false);

                timePickerDialog.show();

            }
        });



    }
    public void showTime(int hour, int min) {
        if (hour == 0) {
            hour += 12;
            format = "AM";
        } else if (hour == 12) {
            format = "PM";
        } else if (hour > 12) {
            hour -= 12;
            format = "PM";
        } else {
            format = "AM";
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.delete_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if(id == android.R.id.home)
        {
            startActivity(new Intent(Updatemessage.this,Listmessage.class));
            this.finish();
        }
        if(item.getItemId()==R.id.delete)
        {
            AlertDelete();
        }
        return super.onOptionsItemSelected(item);
    }

    private void AlertDelete() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Suppression ").setMessage("Voulez-vous vraiment supprimer ce message !").setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        bdEntity.DeleteMessage(id);
                        Toast.makeText(Updatemessage.this,"Message Deleted...",Toast.LENGTH_LONG).show();
                        Intent i1 = new Intent(Updatemessage.this,Listmessage.class);
                        startActivity(i1);
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
}

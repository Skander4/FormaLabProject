package tn.formalab.myproject;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class AdapterClass extends ArrayAdapter<MyEntity> {

    private Context ctx;
    private int item;

    public AdapterClass(@NonNull Context context, int resource, @NonNull List<MyEntity> objects) {
        super(context, resource, objects);
        this.ctx= context;
        this.item= resource;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        convertView = LayoutInflater.from(ctx).inflate(item,parent,false);

        TextView message= convertView.findViewById(R.id.message);
        TextView sender= convertView.findViewById(R.id.sender);
        TextView time= convertView.findViewById(R.id.time);

        MyEntity entity= getItem(position);

        message.setText(entity.getMessage());
        sender.setText(entity.getSender());


        time.setText(entity.getTime());


        return convertView;
    }
}

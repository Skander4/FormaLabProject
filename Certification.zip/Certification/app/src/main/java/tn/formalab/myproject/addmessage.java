package tn.formalab.myproject;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;

import java.util.Calendar;

public class addmessage extends AppCompatActivity {


    EditText message,sender,time;
String format;
   String tm;
    Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addmessage);

          getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("SEND");

        message = findViewById(R.id.message);
        sender = findViewById(R.id.sender);
        time = findViewById(R.id.time);
        submit = findViewById(R.id.addmessagebtn);


        final BDEntity bdEntity = new BDEntity(this);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String msg = message.getText().toString();
                String snd = sender.getText().toString();
                String tm = time.getText().toString();
                MyEntity myEntity = new MyEntity(msg,snd,tm);
                bdEntity.AddEntity(myEntity);

                Intent i = new Intent(addmessage.this,Listmessage.class);
                startActivity(i);
            }
        });

        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               TimePickerDialog timePickerDialog = new TimePickerDialog(addmessage.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                        showTime(hourOfDay,minutes);
                        time.setText(hourOfDay + ":" + minutes + " "+format);
                    }
                }, 0, 0, false);

                timePickerDialog.show();

            }
        });


    }

    public void showTime(int hour, int min) {
        if (hour == 0) {
            hour += 12;
            format = "AM";
        } else if (hour == 12) {
            format = "PM";
        } else if (hour > 12) {
            hour -= 12;
            format = "PM";
        } else {
            format = "AM";
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if(id == android.R.id.home)
        {
            startActivity(new Intent(addmessage.this,MainActivity.class));
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
